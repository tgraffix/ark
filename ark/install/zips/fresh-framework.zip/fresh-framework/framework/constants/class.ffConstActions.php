<?php

class ffConstActions extends ffBasicObject {
	const FILTER_QUERY_GET_ICON = 'ff_filter_query_get_icon';
    const FILTER_QUERY_GET_COLOR = 'ff_filter_query_get_color';

	const FILTER_GET_FONTS = 'ff_filter_get_fonts';

    const ACTION_QUERY_NOT_FOUND_IN_DATA = 'ff_action_query_not_found_in_data';

    const ACTION_LOAD_OUR_THEME = 'ff_action_load_our_theme';
}