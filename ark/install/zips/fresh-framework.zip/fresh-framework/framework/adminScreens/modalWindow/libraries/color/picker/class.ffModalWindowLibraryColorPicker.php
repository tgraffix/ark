<?php

class ffModalWindowLibraryColorPicker extends ffModalWindow {
	protected function _initialize() {
		$this->_setMenuName('Select Color');
	}
}