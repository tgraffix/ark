<?php

class ffThemeBlConst extends ffBasicObject {
	const ANIMATION = 'ffBlAnimation';
	const BUTTON = 'ffBlButton';
	const COMMENTS = 'ffBlComments';
	const CONTENT = 'ffBlBlogContent';
	const FEATUREDIMG = 'ffBlFeaturedImage';
	const ICONS = 'ffBlIcons';
	const IMAGE = 'ffBlImage';
	const LISTBASIC = 'ffBlList';
	const PAGETITLE = 'ffBlPageTitle';
	const PAGINATION = 'ffBlPagination';
}